import disassembler

def main():
    x = 10
    y = 0
    print(x/y)

disassembler.disassemble(main)
