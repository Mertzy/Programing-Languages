/* 
 * File:   PyTuple.cpp
 * Author: Kent D. Lee
 * (c) 2013
 * Created on March 7, 2013, 11:26 PM
 * 
 * License:
 * Please read the LICENSE file in this distribution for details regarding
 * the licensing of this code. This code is freely available for educational
 * use. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 * 
 * Description:
 * See the associated header file for a description of the purpose of this 
 * class. Implementation details are provided here. Read below for 
 * any specific details. 
 * 
 */

#include "PyTuple.h"
#include "PyTupleIterator.h"
#include "PyException.h"
#include "PyInt.h"
#include "PyType.h"
#include "PyBuiltInRepr.h"
#include "PyStr.h"
#include "PyBool.h"
#include "PyDict.h"
#include "PyDictIterator.h" 
#include <sstream>
#include <vector>
using namespace std;

PyTuple::PyTuple(vector<PyObject*>* lst) : PyObject() {
    data = *lst;
    
    dict["__getitem__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyTuple::__getitem__);
    dict["__len__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyTuple::__len__);
    dict["__iter__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyTuple::__iter__);
    dict["__repr__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyTuple::__repr__);
    dict["__hash__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyTuple::__hash__);  
    dict["__eq__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyTuple::__eq__);    
}

PyTuple::~PyTuple() {
}

PyType* PyTuple::getType() {
    return PyTypes[PyTupleType];
}

int PyTuple::size() {
    return data.size();
}

string PyTuple::toString() {
    ostringstream s;
    
    s << "(";
    
    for (int i=0;i<data.size();i++) {
        if (data[i]->getType()->typeId()==PyStrType) 
            s << "\'" << data[i]->toString() << "\'";
        else
            s << data[i]->toString();
        
        if (i < data.size()-1) 
            s << ", ";
        
    }
    
    s << ")";
    
    return s.str();
}

PyObject* PyTuple::getVal(int index) {
        if (index >= data.size()) {
        throw new PyException(PYSTOPITERATIONEXCEPTION,"Stop Iteration");
    }
    
    return data[index];
}

PyObject* PyTuple::__getitem__(vector<PyObject*>* args) {
    ostringstream msg; 

    if (args->size() != 1) {
        msg << "TypeError: expected 1 arguments, got " << args->size();
        throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());  
    }
    
    PyInt* intObj = (PyInt*) (*args)[0];
    
    int index = intObj->getVal();
    
    if (index >= data.size()) {
        throw new PyException(PYILLEGALOPERATIONEXCEPTION,"Index out of range.");
    }
    
    return data[index];
}

PyObject* PyTuple::__len__(vector<PyObject*>* args) {
    ostringstream msg;

    if (args->size() != 0) {
        msg << "TypeError: expected 0 arguments, got " << args->size();
        throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());  
    }
    return new PyInt(data.size());
}

PyObject* PyTuple::__iter__(vector<PyObject*>* args) {
    ostringstream msg;
    
    if (args->size() != 0) {
        msg << "TypeError: expected 0 arguments, got " << args->size();
        throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());  
    }
    
    return new PyTupleIterator(this);
}

PyObject* PyTuple::__repr__(vector<PyObject*>* args) {

    ostringstream s;
    
    s << "(";
    
    for (int i=0;i<data.size();i++) {
        if (data[i]->getType()->typeId()==PyStrType) 
            s << "\'" << data[i]->toString() << "\'";
        else
            s << data[i]->toString();
        
        if (i < data.size()-1) 
            s << ", ";
        
    }
    
    s << ")";
    
    return new PyStr(s.str());


    }



PyObject* PyTuple::__hash__(vector<PyObject*>* args) {

    int k;
    unsigned int hashVal = 0;

    for (k=0;k<data.size();k++) {
        PyObject* obj = data[k];

        PyInt* hObj = (PyInt*) obj->callMethod("__hash__",args);

        hashVal = hashVal/2 + hObj->getVal()/2;

    }

    return new PyInt(hashVal);

}

PyObject* PyTuple::__eq__(vector<PyObject*>* args) {
    ostringstream msg;

    if (args->size() != 1) {
        msg << "TypeError: expected 1 arguments, got " << args->size();
        throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());
    }

    PyObject* obj = (*args)[0]; // (*args)[0]

    if (obj->getType() != this->getType())
        return new PyBool(false);

    //We should check the type of args[0] before casting it.
    PyTuple* other = (PyTuple*) (*args)[0];

    if (other->size() != this->data.size())
        return new PyBool(false);

    int k;

    for (k=0;k<data.size();k++) {
        vector<PyObject*>* v = new vector<PyObject*>();
        v->push_back(other->data[k]);
        PyBool* b = (PyBool*) data[k]->callMethod("__eq__",v);

        if (b->getVal()==false)
            return new PyBool(false);
    }

    return new PyBool(true);

}

