#include <iostream>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <csignal>
#include <stdlib.h>
#include <string>
#include "PyDict.h"
//#include "PyDictIterator.h"
/*
#include "PyObject.h"
#include "PyDict.h"
#include "PyInt.h"
#include "PyBool.h"
#include "PyException.h"
#include "PyStr.h"
#include "PyException.h"
#include "PyDictIterator.h"
*/
using namespace std;

PyDict::PyDict() {

    unordered_map<PyObject*,PyObject*,PyHash,PyKeysEqual> dictMap;
   
    dict["__getitem__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyDict::__getitem__);
    dict["__setitem__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyDict::__setitem__);
    dict["__len__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyDict::__len__);
    dict["__iter__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyDict::__iter__);
    dict["keys"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyDict::keys);
    dict["values"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyDict::values);
    
}

std::size_t PyHash::operator() (const PyObject* key) const {
    vector<PyObject*> args;
    PyInt* hashVal = (PyInt*) const_cast<PyObject*>(key)->callMethod("__hash__",&args);
    return hashVal->getVal();

}

bool PyKeysEqual::operator() (const PyObject* key1, const PyObject* key2) const {

    vector<PyObject*> args;
    args.push_back(const_cast <PyObject*>(key2));
    PyBool* test = (PyBool*) const_cast<PyObject*>(key1)->callMethod("__eq__",&args);
    return test->getVal();

}

string PyDict::toString() {
    unordered_map<PyObject*,PyObject*,PyHash,PyKeysEqual>::iterator it;
    ostringstream s;
    s << "{";
    it = dictMap.begin();
    while (it!=dictMap.end()) {
        s << it->first->toString() << ": " << it->second->toString();
        it++;
        if (it!=dictMap.end())
            s << ", ";
    }
    s << "}";
    return s.str();
}

PyObject* PyDict::__iter__(vector<PyObject*>* args) {
    ostringstream msg;

    if (args->size() != 0) {
        msg << "TypeError: expected 0 arguments, got " << args->size();
        throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());
    }

    return new PyDictIterator(&dictMap);
}

PyObject* PyDict::getVal(PyObject* key) {

    auto searcher = dictMap.find(key);

    if (searcher == dictMap.end()) {

        cout << "Error, not found" << endl;

    } 

    else {

        return searcher->second;

    }

}

PyObject* PyDict::__getitem__(vector<PyObject*>* args) {

    PyObject* keyToFind = (PyObject*) (*args)[0];

    auto searcher = dictMap.find(keyToFind);

    if (searcher == dictMap.end()) {

        cout << "Error: Value Not Found" << endl;

    } 

    else {

        return searcher->second;

    }


}

PyType* PyDict::getType() {


    return PyTypes[PyDictType];

}

PyDict::~PyDict() {

}

void PyDict::setVal(PyObject* key, PyObject* val) {

    pair<PyObject*, PyObject*> newPair(key, val);
    dictMap.insert(newPair);

}

PyObject* PyDict::__setitem__(vector<PyObject*>* args) {

    ostringstream msg;

    if (args->size() != 2) {
        msg << "TypeError. Expected 2 arguments. Recieved " << args->size();
        throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());

    }

    PyObject* newKey = (PyObject*) (*args)[0];
    PyObject* newVal = (PyObject*) (*args)[1];

    pair<PyObject*, PyObject*> newPair (newKey, newVal);

    dictMap.insert(newPair);

    return new PyNone();  //potential change

}



PyObject* PyDict::__len__(vector<PyObject*>* args) {

    ostringstream msg;

    if (args->size() != 0) {
        msg << "TypeError: expected 0 arguments, got " << args->size();
        throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());
    }

    return new PyInt(dictMap.size());


}

PyObject* PyDict::keys(vector<PyObject*>* args) {

    vector<PyObject*>* totalKeys = new vector<PyObject*>();

    for (auto keyVals : dictMap) {

        totalKeys->push_back(keyVals.first);

    }

    return new PyList(totalKeys);

}

PyObject* PyDict::values(vector<PyObject*>* args) {

    vector<PyObject*>* totalValues = new vector<PyObject*>();

    for (auto vals : dictMap) {

        totalValues->push_back(vals.second);

    }

    return new PyList(totalValues);
    
}





