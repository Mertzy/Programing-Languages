#ifndef PYDICTITERATOR_H
#define	PYDICTITERATOR_H

#include "PyObject.h"
#include "PyType.h"
#include "PyDict.h"
#include "PyException.h"
#include <string>
#include <sstream>


#include <unordered_map>
using namespace std;

class PyDictIterator : public PyObject {
public:
    PyDictIterator(unordered_map<PyObject*, PyObject*, PyHash, PyKeysEqual>* dictMap);

    virtual ~PyDictIterator(); 

    PyType* getType();
    string toString();

protected:
    int index;

    unordered_map<PyObject*, PyObject*, PyHash, PyKeysEqual>* dictMap;
    unordered_map<PyObject*, PyObject*, PyHash, PyKeysEqual>::iterator item;


    virtual PyObject* __iter__(vector<PyObject*>* args);
    virtual PyObject* __next__(vector<PyObject*>* args);    

};

#endif	/* PYDICTITERATOR_H */

