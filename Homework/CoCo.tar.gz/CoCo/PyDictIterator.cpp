#include "PyDictIterator.h"
#include "PyDict.h"
#include "PyException.h"
#include <string>

using namespace std;

PyDictIterator::PyDictIterator(unordered_map<PyObject*,PyObject*,PyHash,PyKeysEqual>* dictMap) {

    dictMap = dictMap;
    item = dictMap->begin();

    dict["__iter__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyDictIterator::__iter__);
    dict["__next__"] = (PyObject* (PyObject::*)(vector<PyObject*>*)) (&PyDictIterator::__next__);

}

PyDictIterator::~PyDictIterator() {

}

PyType* PyDictIterator::getType() {

	return PyTypes[PyDictKeyIteratorType];

	}

string PyDictIterator::toString() {

	ostringstream s;

	s << "<dict_iterator object at " << this << ">";

	return s.str();

}

PyObject* PyDictIterator::__iter__(vector<PyObject*>* args) {

	ostringstream msg;

    if (args->size() != 0) {
        msg << "TypeError: expected 0 arguments, got " << args->size();
        throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());  
    }

    item = dictMap->begin();

    return this;

}

PyObject* PyDictIterator::__next__(vector<PyObject*>* args) {

	ostringstream msg;

	if (args->size() != 0) {
        msg << "TypeError: expected 0 arguments, got " << args->size();
        throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());  
    }

    if (item == dictMap->end()) {

    	msg << "Went past end of dictionary.";
    	throw new PyException(PYWRONGARGCOUNTEXCEPTION,msg.str());  


    }

   	PyObject* val = item->first;

   	item++;

   	return val;



}
