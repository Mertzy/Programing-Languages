

#include "PyObject.h"
#include "PyType.h"
#include "PyInt.h"
#include "PyBool.h"
#include "PyNone.h"
#include "PyList.h"
#include "PyException.h"
#include <unordered_map>
#include <vector>
#include <unordered_map>
#include "PyDictIterator.h"

#ifndef PYDICT_H
#define PYDICT_H

#include <unordered_map>

using namespace std;

class PyHash
{

public:

    std::size_t operator() (const PyObject* key) const; //done

};

class PyKeysEqual 

{

public:

    bool operator() (const PyObject* key1, const PyObject* key2) const; //done

};

class PyDict : public PyObject {
public:

    PyDict(); //done
    virtual ~PyDict(); //done
    PyType* getType(); //done
    string toString(); //done
    PyObject* getVal(PyObject* key); //done
    void setVal(PyObject* key, PyObject* val); //done

protected:

    unordered_map<PyObject*,PyObject*,PyHash,PyKeysEqual> dictMap;
    unordered_map<PyObject*,PyObject*,PyHash,PyKeysEqual>::iterator item;

    virtual PyObject* __getitem__(vector<PyObject*>* args); //done
    virtual PyObject* __setitem__(vector<PyObject*>* args); //done
    virtual PyObject* __len__(vector<PyObject*>* args); //done
    virtual PyObject* __iter__(vector<PyObject*>* args); //done
    virtual PyObject* keys(vector<PyObject*>* args); //done
    virtual PyObject* values(vector<PyObject*>* args); //done

};

#endif  /* PYDICT_H */