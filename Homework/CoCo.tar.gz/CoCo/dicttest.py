import disassembler


def main():
  
    d = { "Kent":"Denise", "Sophus":"Addie"}
    print(d)


disassembler.disassemble(main)