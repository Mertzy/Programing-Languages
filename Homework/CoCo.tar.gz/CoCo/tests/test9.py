import disassembler

def main():
    x = int(input("Please enter an integer: "))
    print(x+1)
    
disassembler.disassemble(main)

    
    