import disassembler

def main():
	s = input("Enter a list of integers:")
	lst = s.split()

	print(lst)

#main()
disassembler.disassemble(main)