import disassembler

def main():

    x = [1,2,3]
    print(x.__setitem__(2,6))

#main()
disassembler.disassemble(main)
