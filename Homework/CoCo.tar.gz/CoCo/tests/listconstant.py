import disassembler

def main():
	lst = ["hello","world"]
	print(lst)

#main()
disassembler.disassemble(main)