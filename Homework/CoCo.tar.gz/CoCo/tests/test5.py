import disassembler

def main():
    x=5
    print((x+7,x))
    
disassembler.disassemble(main)
