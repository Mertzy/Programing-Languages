from disassembler import *

def main():
    x = iter(range(5))
    print(x)
    
disassemble(main)