import disassembler

def main():
    x = 5
    y = x + 5
    print(y+5)
    
disassembler.disassemble(main)
    