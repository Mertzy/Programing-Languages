from disassembler import *

def main():
    
    def f(x):
    
        print(type(x))
    
    f(2)
    
disassemble(main)
    
