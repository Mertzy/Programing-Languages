from disassembler import *

def main():
    x = 5
    print(x)
    
disassemble(main)
    