import disassembler

def main():
	x = 5
	y = 6
	if x > y:
		print(x)

	print(y)

#main()

disassembler.disassemble(main)