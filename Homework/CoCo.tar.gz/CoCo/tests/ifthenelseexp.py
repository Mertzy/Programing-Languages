import disassembler

def main():
	x = 5
	y = 6
	print(x if x > y else y)

#main()

disassembler.disassemble(main)