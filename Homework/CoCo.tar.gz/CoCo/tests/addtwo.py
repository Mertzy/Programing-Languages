from disassembler import *

def main():
	x = 5
	y = 6
	z = x + y
	print(z)

disassemble(main)