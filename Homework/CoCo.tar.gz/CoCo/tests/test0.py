import disassembler

def main():
    print(5+5)
    
disassembler.disassemble(main)
    