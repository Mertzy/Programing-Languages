import disassembler

def main():

    x = "How\'s it going"
    print(x)

disassembler.disassemble(main)
